'''
David Wood
PLTW CSE 1.3.8
'''
'''
  Program generates a random number and a random guess
  Uses a binary search algorithm to narrow the number of guesses down
  no input required
  
  log(n) attempts to correctly find the guess n = guess
'''
import random
def goGuess():
    count = 1
    low = 1
    high = 20 
    answer = random.randint(low, high)
    guess = random.randint(low, high)    
    while guess != answer:
        if guess < answer:
            count = count + 1;
            print str(guess) + ' is too low.'
            low = guess + 1
            guess = random.randint(low,high)
        else:
            count = count + 1
            print str(guess) + ' is too high'
            high = guess - 1
            guess = random.randint(low,high)
    print 'Right! The number is ' + str(answer) + ' You got it in ' + str(count) + ' guesses' 



def goGuessComputer(answer):
    count = 1
    low = 1
    high = 20 
    #answer = random.randint(low, high)
    guess = random.randint(low, high)    
    while guess != answer:
        if guess < answer:
            count = count + 1;
            print str(guess) + ' is too low.'
            low = guess + 1
            guess = random.randint(low,high)
        else:
            count = count + 1
            print str(guess) + ' is too high'
            high = guess - 1
            guess = random.randint(low,high)
    print 'Right! The number is ' + str(answer) + ' You got it in ' + str(count) + ' guesses' 



    
goGuess() 
goGuessComputer(2)
    
    